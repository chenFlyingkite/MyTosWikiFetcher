﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace FlurryLoginHelper
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            updateRegistyKeyToSupportLatestVersionIE();
            webBrowser1.ScriptErrorsSuppressed = true; //To avoid IE script error dialog jump  up.
        }


        private const String TEXT_FLURRY_LOGIN_URL = @"https://login.flurry.com/home";
        private ProcessStatus mStatus;
        public enum ProcessStatus
        {
            Login,
            WaitForLogin,
            GotoTargetPage,
            LoadTargetPageComplete
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            // Check the page is at error page for error handling.
            if (checkIsErrorPage())
            {
                MessageBox.Show("Is enter error page,auto Restart");
                btStart_Click(null, null);
                return;
            }

            if (mStatus == ProcessStatus.Login)
            {
                if (login())
                {
                    mStatus = ProcessStatus.WaitForLogin;
                }
            }
            else if (mStatus == ProcessStatus.WaitForLogin)
            {
                if (checkIsLogin())
                {
                    mStatus = ProcessStatus.GotoTargetPage;
                    goToTargetPage();
                }
            }
            else if (mStatus == ProcessStatus.GotoTargetPage)
            {
                if (checkIsTargetPage())
                {
                    mStatus = ProcessStatus.LoadTargetPageComplete;
                    MessageBox.Show("LoadTargetPageComplete");
                }
            }
            updateStatusLabel();
        }


        private Boolean login()
        {
            try
            {
                HtmlElement username = webBrowser1.Document.All["username"];
                username.SetAttribute("value", "Appdev@cyberlink.com");

                HtmlElement password = webBrowser1.Document.All["password"];
                password.SetAttribute("value", "23829868");

                // Delay to click login button
                bgClickLoginWithDelay.RunWorkerAsync();
            }
            catch (Exception e)
            {
                MessageBox.Show("error:" + e);
                return false;
            }
            return true;
        }

        private Boolean findAndClickSubmitButton()
        {
            //look for all button and find submit button
            foreach (HtmlElement he in webBrowser1.Document.GetElementsByTagName("button"))
            {
                if (he.GetAttribute("type") == "submit")
                {
                    he.InvokeMember("click");
                    return true;
                }
            }
            return false;
        }

        private Boolean checkIsLogin()
        {
            if (webBrowser1.Url.ToString().Contains(@"https://y.flurry.com/metrics"))
            {
                return true;
            }
            return false;
        }

        private bool checkIsTargetPage()
        {
            if (webBrowser1.Url.ToString().Contains(txtTargetPageUrl.Text))
            {
                return true;
            }
            return false;
        }

        private void goToTargetPage()
        {
            webBrowser1.Navigate(txtTargetPageUrl.Text);
        }

        private Boolean checkIsErrorPage()
        {
            System.IO.StreamReader getReader = new System.IO.StreamReader(webBrowser1.DocumentStream, System.Text.Encoding.Default);
            string html = getReader.ReadToEnd();
            if (html.Contains("Oops, an unexpected error has occurred"))
            {
                return true;
            }
            return false;
        }
        private void updateStatusLabel()
        {
            txtStatus.Text = mStatus.ToString();
        }

        private void btStart_Click(object sender, EventArgs e)
        {
            mStatus = ProcessStatus.Login;
            webBrowser1.Navigate(TEXT_FLURRY_LOGIN_URL);
            updateStatusLabel();
        }


     
        private void bgClickLoginWithDelay_DoWork(object sender, DoWorkEventArgs e)
        {
            Thread.Sleep(1000);
        }

        private void bgClickLoginWithDelay_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            findAndClickSubmitButton();
        }

        private void updateRegistyKeyToSupportLatestVersionIE()
        {

            int BrowserVer, RegVal;

            // get the installed IE version
            using (WebBrowser Wb = new WebBrowser())
                BrowserVer = Wb.Version.Major;

            // set the appropriate IE version
            if (BrowserVer >= 11)
                RegVal = 11001;
            else if (BrowserVer == 10)
                RegVal = 10001;
            else if (BrowserVer == 9)
                RegVal = 9999;
            else if (BrowserVer == 8)
                RegVal = 8888;
            else
                RegVal = 7000;

            // set the actual key
            RegistryKey Key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION", true);
            Key.SetValue(System.Diagnostics.Process.GetCurrentProcess().ProcessName + ".exe", RegVal, RegistryValueKind.DWord);
            Key.Close();
        }

    }
}
